const express=require('express');
const router=express.Router();
const Item=require('../models/Producto');

//Registrar un producto

//Consultar todos los productos

//Consultar producto por id

//Modificar datos del producto

//Eliminar un producto

module.exports=router;
